import { HelloService } from './hello.service';
import { Controller, Post, Body, Get, Header } from '@nestjs/common'; 
import { PersonDto } from './dto/person.dto';

@Controller('hello')
export class HelloController {
    constructor(
        private readonly helloService: HelloService,         
        ) {}
    @Post('welcome')
    @Header('Content-Type', 'application/json')
    async sayWelcome(@Body() personDto: PersonDto): Promise<{data : String}> {
        let msg = await this.helloService.welcome(personDto);
        return  {data :msg};      // check if the user exists in the db

    }

}